import 'zone.js/dist/zone.js';

import 'core-js/es';
import 'core-js/proposals/reflect-metadata';