// // 1. Element Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-comp-one',
//   template: `
//     <h1 class="text-info">Hello from Component One</h1>
//     <h2 style="border-style:solid; border-width: 2px; border-color: blue">From Component One</h2>
//   `,
//   styles: []
// })
// export class CompOneComponent implements OnInit {
//   constructor() { }
//   ngOnInit() {
//   }
// }

// 2. Template Inline Style
// import { Component, OnInit, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'app-comp-one',
//   template: `
//     <style>
//       .card {
//         border-style:solid; 
//         border-width: 2px; 
//         border-color: blue;
//       }
//     </style>
//     <h1 class="text-info">Hello from Component One</h1>
//     <h2 class="card">From Component One</h2>
//   `,
//   encapsulation: ViewEncapsulation.Emulated
// })
// export class CompOneComponent implements OnInit {
//   constructor() { }
//   ngOnInit() {
//   }
// }

// 3. Component Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-comp-one',
//   template: `
//     <h1 class="text-info">Hello from Component One</h1>
//     <h2 class="card">From Component One</h2>
//   `,
//   styles: [`
//     .card {
//       border-style:solid; 
//       border-width: 2px; 
//       border-color: blue;
//     }
//   `]
// })
// export class CompOneComponent implements OnInit {
//   constructor() { }
//   ngOnInit() {
//   }
// }

// 4. External CSS
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h1 class="text-info">Hello from Component One</h1>
    <h2 class="card">From Component One</h2>
  `,
  styleUrls: ['./comp-one.component.css']
})
export class CompOneComponent implements OnInit {
  constructor() { }
  ngOnInit() {
  }
}