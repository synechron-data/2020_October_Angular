import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'c-two',
  template: `
    <h2 class="text-success">Hello from Component Two - Module Two!</h2>
    <s-com></s-com>
  `,
  styles: []
})
export class CTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
