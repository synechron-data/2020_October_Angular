import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'c-one',
  template: `
    <h2 class="text-info">Hello from Component One - Module One!</h2>
    <s-com></s-com>
  `,
  styles: []
})
export class COneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
