import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { COneComponent } from './components/c-one/c-one.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [COneComponent],
  imports: [CommonModule, SharedModule],
  exports: [COneComponent]
})
export class MOneModule { }
