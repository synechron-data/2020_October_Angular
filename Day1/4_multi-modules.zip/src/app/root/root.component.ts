import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1 class="text-danger">Hello from Root One - Root Module!</h1>
      <hr/>
      <c-one></c-one>
      <c-two></c-two>
    </div>
  `
})
export class RootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
