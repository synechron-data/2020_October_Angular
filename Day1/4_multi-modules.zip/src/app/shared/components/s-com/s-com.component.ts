import { Component, OnInit } from '@angular/core';

@Component({
  selector: 's-com',
  template: `
    <h3 class="text-warning">Shared Component - Shared Module!</h3>
  `,
  styles: []
})
export class SComComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
