import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SComComponent } from './components/s-com/s-com.component';

@NgModule({
  declarations: [SComComponent],
  imports: [
    CommonModule
  ],
  exports: [SComComponent]
})
export class SharedModule { }
