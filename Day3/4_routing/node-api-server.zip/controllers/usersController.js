const da = require('../dataaccess');

module.exports.index = function (req, res, next) {
    var msg = req.query.msg;
    da.getAllUsers().then(function (data) {
        res.json({ success: true, users: data });
    }, function (eMsg) {
        res.json({ success: false, message: eMsg });
    })
}

// var data = [
//     {
//         _id: '5ddfa184223d0f9a66ebe7c1',
//         username: 'User One',
//         email: 'user1@abc.com'
//     },
//     {
//         _id: '5ddfa1b5223d0f9a66ebe7c2',
//         username: 'User Two',
//         email: 'user2@abc.com'
//     }
// ];