import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { lazyRoutes } from './lazy.routes';

import { LazyOneComponent } from './components/lazy-one/lazy-one.component';

@NgModule({
  declarations: [LazyOneComponent],
  imports: [CommonModule, RouterModule.forChild(lazyRoutes)],
  exports: [RouterModule]
})
export class LazyModule { }
