import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from '@angular/core';

import { catchError, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";

@Injectable()
export class UsersService {
  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = "http://localhost:8000/api/users";
  }

  getAllUsers() {
    return this.httpClient.get<Array<any>>(this.url).pipe(
      retry(3),
      catchError(this._handleError<any>('getAllUsers', []))
    );
  }

  private _handleError<T>(operation = 'operation', result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      console.log(`${operation} failed: ${err.message}`);
      return throwError(err.message);
    }
  }
}
