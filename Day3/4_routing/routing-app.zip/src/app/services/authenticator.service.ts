import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { map } from "rxjs/Operators";

@Injectable()
export class AuthenticatorService {
  private url = "http://localhost:8000/api/authenticate";

  constructor(private httpClient: HttpClient) { }

  login(username: string, password: string) {
    return this.httpClient.post<any>(this.url, { username: username, password: password }).pipe(map(resObject => {
      if (resObject && resObject.token) {
        sessionStorage.setItem('tk', resObject.token);
      }
      return resObject;
    }));
  }

  getToken() {
    return sessionStorage.getItem("tk");
  }

  logout() {
    sessionStorage.removeItem("tk");
  }
}
