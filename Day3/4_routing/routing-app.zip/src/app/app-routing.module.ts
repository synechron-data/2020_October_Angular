import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthorRootComponent } from './authors-module/components/author-root/author-root.component';
import { AboutComponent } from './components/about/about.component';
import { AdminComponent } from './components/admin/admin.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { ProductNotSelectedComponent } from './components/product-not-selected/product-not-selected.component';
import { ProductsComponent } from './components/products/products.component';
import { AuthGuardService } from './services/auth-guard.service';

const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    { path: 'authors', component: AuthorRootComponent },
    {
        path: 'products',
        component: ProductsComponent,
        children: [
            { path: '', component: ProductNotSelectedComponent },
            { path: ':id', component: ProductDetailsComponent }
        ]
    },
    { path: 'lazy', loadChildren: './lazy-module/lazy-module.module#LazyModule' },
    { path: 'admin', component: AdminComponent, canActivate: [AuthGuardService] },
    { path: 'login', component: LoginComponent },
    { path: '**', component: NotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }