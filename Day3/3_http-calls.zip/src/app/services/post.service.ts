import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';

import { catchError, delay, retry } from 'rxjs/operators';

import { Post } from '../models/post.model';

// @Injectable()
@Injectable({
    providedIn: 'root'
})
export class PostService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = "https://jsonplaceholder.typicode.com/posts";
    }

    // getPosts() {
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError<Array<Post>>('getPosts', []))
        );
    }

    insertPost(p: Post) {
        return this.httpClient.post<Post>(this.url, p).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError<Post>('addPost', p))
        );
    }

    deletePost(postId: number) {
        var deleteUrl = `${this.url}/${postId}`;
        return this.httpClient.delete(deleteUrl).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('deletePost'))
        );
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.log(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later....');
        };
    }
}