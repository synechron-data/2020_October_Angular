import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'async-observable',
  template: `
    <h2 class="text-info">With Observables</h2>
    <h3>Result: {{observableData}}</h3>
    <h3>Observable: {{observableResult | async}}</h3>
  `,
  styles: []
})
export class AsyncObservableComponent implements OnInit, OnDestroy {
  observableData: number;
  observableResult: Observable<number>;

  sOne: Subscription;

  constructor() { }

  ngOnInit() {
    this.sOne = this.getObservable().subscribe(n => this.observableData = n);
    this.observableResult = this.getObservable();
  }

  getObservable(): Observable<number> {
    return interval(2000).pipe(map(o => Math.random()));
  }

  ngOnDestroy(): void {
    this.sOne.unsubscribe();
  }
}
