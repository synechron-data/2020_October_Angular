import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RootComponent } from './root/root.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListComponent } from './list/list.component';
import { CaptionPipe } from './pipes/caption.pipe';
import { FilterPipe } from './pipes/filter.pipe';

@NgModule({
  declarations: [RootComponent, ListComponent, CaptionPipe, FilterPipe],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }
