import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { RootComponent } from './root/root.component';
import { AssignOneComponent } from './assign-one/assign-one.component';
import { AssignTwoComponent } from './assign-two/assign-two.component';

@NgModule({
  declarations: [RootComponent, AssignOneComponent, AssignTwoComponent],
  imports: [BrowserModule, FormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }
