import { AfterViewInit, Component, NgZone, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styles: []
})
export class RootComponent implements OnInit, AfterViewInit {
  message: string;
  flag: boolean;
  imageSource: any;
  h: number;
  w: number;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!";
    this.flag = false;
    this.imageSource = require('../../assets/image1.jpg');
    this.h = 200;
    this.w = 200;
  }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS").addEventListener("click", () => {
    //   this.message = new Date().toTimeString();
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS").addEventListener("click", () => {
        this.message = new Date().toTimeString();
        console.log(this.message);
      });
    })
  }

  ngOnInit() {
  }

  doChange() {
    this.message = new Date().toTimeString();
  }

  doUpdate(city: string) {
    this.message = `You are from: ${city}`;
  }
}
