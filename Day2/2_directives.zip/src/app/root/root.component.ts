import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styles: []
})
export class RootComponent implements OnInit {
  myStyles = {
    'background-color': 'green',
    'font-size': '20px',
    'color': 'white'
  };

  name: string;

  constructor() {
    // this.name = "Synechron";
  }

  ngOnInit() {
  }
}
