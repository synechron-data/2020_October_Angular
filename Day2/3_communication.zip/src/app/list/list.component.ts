import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html'
})
export class ListComponent implements OnInit {
  @Input() personList: Array<string>;
  selected: string;

  constructor() { }

  ngOnInit() {
  }

  select(name: string, event: Event) {
    this.selected = name;
    event.preventDefault();
  }
}
