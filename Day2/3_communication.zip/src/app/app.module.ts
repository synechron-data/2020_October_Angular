import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RootComponent } from './root/root.component';
import { ListComponent } from './list/list.component';
import { CounterComponent } from './counter/counter.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [RootComponent, ListComponent, CounterComponent],
  imports: [BrowserModule, FormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }
